return {
  rotate = require "plenary.vararg.rotate",
}
