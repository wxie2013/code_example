local win_float = {}

win_float.default_options = {}

function win_float.default_opts()
  return {}
end

function win_float.percentage_range_window() end

return win_float
