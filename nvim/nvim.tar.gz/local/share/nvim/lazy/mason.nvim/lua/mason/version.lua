local M = {}

M.VERSION = "v2.0.1" -- x-release-please-version
M.MAJOR_VERSION = 2 -- x-release-please-major
M.MINOR_VERSION = 0 -- x-release-please-minor
M.PATCH_VERSION = 1 -- x-release-please-patch

return M
