return {
    bundle_path = vim.fn.expand "$MASON/packages/powershell-editor-services",
}
