return {
    cmd = { "lexical" },
}
