return {
    cmd = { "raku-navigator", "--stdio" },
}
