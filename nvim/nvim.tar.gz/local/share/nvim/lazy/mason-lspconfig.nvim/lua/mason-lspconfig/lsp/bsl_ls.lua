return {
    cmd = { "bsl-language-server" },
}
