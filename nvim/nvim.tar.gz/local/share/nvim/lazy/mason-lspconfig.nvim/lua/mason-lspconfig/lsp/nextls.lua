return {
    cmd = { "nextls", "--stdio" },
}
