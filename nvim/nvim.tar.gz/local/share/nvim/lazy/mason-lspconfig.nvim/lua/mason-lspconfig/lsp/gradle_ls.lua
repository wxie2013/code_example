return {
    cmd = { "gradle-language-server" },
}
